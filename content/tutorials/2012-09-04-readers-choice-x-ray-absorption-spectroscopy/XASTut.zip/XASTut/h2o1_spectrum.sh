# where you put your pseudos, or leave default
pseudo_dir='./pseudo/'
# where you want to write scratch files.
outdir=''
#where your main espresso distribution is
ESPRESSOROOT=''
for method in fch nch; do
if [ "$method" == "fch" ]; then
pseudo="O.star1s-pbe-van_gipaw.UPF"
charge="1.0"
else
pseudo="O.pbe-van_gipaw.UPF"
charge="0.0"
fi
cat > h2o1_$method.scf.in << EOF
 &control
    calculation='scf',
    pseudo_dir = '$pseudo_dir'
    outdir='$outdir',
    prefix='h2o1_$method',
 /
 &system
    ibrav = 1,
    celldm(1) = 20.0,
    nat=3,
    ntyp=2,
    nbnd=24,
    tot_charge=$charge,
    ecutwfc=25.0,
    ecutrho=250.0,
 /
 &electrons
    mixing_beta = 0.3,
 /
ATOMIC_SPECIES
O_h 16.0 $pseudo
H   1.00 HUSPBE.RRKJ3
ATOMIC_POSITIONS angstroms
O_h      0.000000000  -0.196963910   0.000000000
H        0.000000000   0.398481955   0.771546569
H        0.000000000   0.398481955  -0.771546569
K_POINTS automatic
1 1 1 0 0 0
EOF
printf "Starting SCF for "$method
$ESPRESSOROOT/bin/pw.x < h2o1_$method.scf.in > h2o1_$method.scf.out
printf "...done.\n"
printf "Generating reference WFC for "$method
$ESPRESSOROOT/XSpectra/tools/upf2plotcore.sh < $pseudo_dir/$pseudo > O_h.wfc
printf "...done.\n" 
cat > h2o1_$method.xspectra_fermi.in << EOF
 &input_xspectra
    calculation='fermi_level',
    prefix='h2o1_$method',
    outdir='$outdir',
    xread_wf=.true.,
 /
 &plot
 /
 &pseudos
    filecore='O_h.wfc',
 /
 &cut_occ
 /
1 1 1  0 0 0
done
EOF
printf "Starting Fermi calculation for "$method
$ESPRESSOROOT/XSpectra/src/xspectra.x < h2o1_$method.xspectra_fermi.in > h2o1_$method.xspectra_fermi.out
printf "...done.\n"
fermi=`grep 'Fermi level' h2o1_$method.xspectra_fermi.out | awk '{ print $6 }'`

cat > h2o1_$method.xspectra.in << EOF
 &input_xspectra
    calculation='xanes_dipole',
    prefix='h2o1_$method',
    outdir='$outdir',
    xonly_plot=.false.,
    xniter=1000,
    xcheck_conv=10,
    xepsilon(1)=1.0,
    xepsilon(2)=0.0,
    xepsilon(3)=0.0,
    xiabs=1,
    x_save_file='h2o1_$method.xspectra.sav',
    ef_r=$fermi,
    xerror=0.001,
 /
 &plot
    xnepoint=1000,
    xgamma=0.25,
    xemin=-10.0,
    xemax=50.0,
    terminator=.true.,
    cut_occ_states=.true.,
 /
 &pseudos
    filecore='O_h.wfc',
    r_paw(1)=3.2,
 /
 &cut_occ
    cut_desmooth=0.1,
    cut_stepl=0.01,
 /
1 1 1 0 0 0
EOF
printf "Starting XANES calculation for "$method
$ESPRESSOROOT/XSpectra/src/xspectra.x < h2o1_$method.xspectra.in > h2o1_$method.xspectra.out 
mv -i xanes.dat h2o1_$method.xspectra.dat
printf "...done.\n"
done
