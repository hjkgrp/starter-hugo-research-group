# where you put your pseudos, or leave default
pseudo_dir='./pseudo/'
# where you want to write scratch files.
outdir=''
#where your main espresso distribution is
ESPRESSOROOT=''
for method in fch nch; do
if [ "$method" == "fch" ]; then
pseudo="O.star1s-pbe-van_gipaw.UPF"
charge="1.0"
else
pseudo="O.pbe-van_gipaw.UPF"
charge="0.0"
fi
cat > h2o5_$method.scf.in << EOF
 &control
    calculation='scf',
    pseudo_dir = '$pseudo_dir'
    outdir='$outdir',
    prefix='h2o5_$method',
 /
 &system
    ibrav = 1,
    celldm(1) = 24.0,
    nat=15,
    ntyp=3,
    nbnd=80,
    tot_charge=$charge,
    ecutwfc=25.0,
    ecutrho=250.0,
 /
 &electrons
    mixing_beta = 0.3,
 /
ATOMIC_SPECIES
O_h 16.0 $pseudo
O 16.0 O.pbe-van_gipaw.UPF
H   1.00 HUSPBE.RRKJ3
ATOMIC_POSITIONS angstroms
 O    97.873900   103.017000   100.816000
 O_h  98.624782   103.078910    97.964595
 O    97.474738   101.395311    96.111586
 O   101.420490   102.238614    97.683092
 O    97.551223   105.800787    97.269344
 H    98.718787   103.506759   101.033004
 H    97.164099   103.675082   100.563046
 H    98.256771   103.927281    97.583892
 H    98.144317   102.859073    98.813005
 H    98.086561   101.737517    96.824290
 H    96.866861   102.130689    95.812746
 H    96.796940   105.863591    97.922758
 H    98.326834   106.337347    97.603117
 H   101.449264   101.294959    98.012627
 H   100.469927   102.546564    97.634686
K_POINTS automatic
1 1 1 0 0 0
EOF
printf "Starting SCF for "$method
$ESPRESSOROOT/bin/pw.x < h2o5_$method.scf.in > h2o5_$method.scf.out
printf "...done.\n"
printf "Generating reference WFC for "$method
$ESPRESSOROOT/XSpectra/tools/upf2plotcore.sh < $pseudo_dir/$pseudo > O_h.wfc
printf "...done.\n" 
cat > h2o5_$method.xspectra_fermi.in << EOF
 &input_xspectra
    calculation='fermi_level',
    prefix='h2o5_$method',
    outdir='$outdir',
    xread_wf=.true.,
 /
 &plot
 /
 &pseudos
    filecore='O_h.wfc',
 /
 &cut_occ
 /
1 1 1  0 0 0
done
EOF
printf "Starting Fermi calculation for "$method
$ESPRESSOROOT/XSpectra/src/xspectra.x < h2o5_$method.xspectra_fermi.in > h2o5_$method.xspectra_fermi.out
printf "...done.\n"
fermi=`grep 'Fermi level' h2o5_$method.xspectra_fermi.out | awk '{ print $6 }'`

cat > h2o5_$method.xspectra.in << EOF
 &input_xspectra
    calculation='xanes_dipole',
    prefix='h2o5_$method',
    outdir='$outdir',
    xonly_plot=.false.,
    xniter=1000,
    xcheck_conv=10,
    xepsilon(1)=1.0,
    xepsilon(2)=0.0,
    xepsilon(3)=0.0,
    xiabs=1,
    x_save_file='h2o5_$method.xspectra.sav',
    ef_r=$fermi,
    xerror=0.001,
 /
 &plot
    xnepoint=1000,
    xgamma=0.25,
    xemin=-10.0,
    xemax=50.0,
    terminator=.true.,
    cut_occ_states=.true.,
 /
 &pseudos
    filecore='O_h.wfc',
    r_paw(1)=3.2,
 /
 &cut_occ
    cut_desmooth=0.1,
    cut_stepl=0.01,
 /
1 1 1 0 0 0
EOF
printf "Starting XANES calculation for "$method
$ESPRESSOROOT/XSpectra/src/xspectra.x < h2o5_$method.xspectra.in > h2o5_$method.xspectra.out 
mv -i xanes.dat h2o5_$method.xspectra.dat
printf "...done.\n"
done
