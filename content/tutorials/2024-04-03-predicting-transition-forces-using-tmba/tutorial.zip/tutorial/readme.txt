dE --- geometries, inputs, and outputs necessary to calculate force free 
reaction 
energy

keff --- geometries, inputs, outputs, and scripts necessary to calculate 
Keff
