150 --- geometry, input and output of the simulation under external 
applied force = 1.5 nN

200 --- geometry, input and output of the simulation under external 
applied force = 2.0 nN

250 --- geometry, input and output of the simulation under external 
applied force = 2.5 nN

cis-acyl --- optimized geometries of cis-acyl-NEO under tension

calculate_keff.py --- python script for calculating keff using the 
optimized geometries
