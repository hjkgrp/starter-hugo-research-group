from molSimplify.Classes.mol3D import mol3D, atom3D
import os
import numpy as np

dir = os.getcwd() + '/'
dirs = ['cis-acyl/'] # directories that contain different mechanophores
files = ['150.xyz', '200.xyz',  '250.xyz'] # file names within each directory
distances_1 = []
#distances_2 = [] # define number of distance lists that match number of directories
#distances_3 = []
Forces = [1.5,2,2.5] # forces (in nN) that were used to optimize each structure
for i in range(len(files)): #iterate through different optimized structures
    structure_1 = dir+dirs[0]+files[i] #structure path
    mymol_1 = mol3D() # define mol3D object
    mymol_1.readfromxyz(structure_1) # read xyz file into mol3D object
    atom_1 = mymol_1.getAtom(16) # define first C atom
    atom_2 = mymol_1.getAtom(21) # define second C atom
    distance_1 = atom_1.distance(atom_2) # calculate distance between two C atoms
    distances_1.append(distance_1) # Record calculated distance

m_1, b_1 = np.polyfit(distances_1, Forces, 1) # calculate slope and intercept of a linear fit


print(distances_1)
print(m_1)

# Plotting force distance plot

x_1 = np.array([1.574,1.64])


import os
import sys
import pandas as pd
import seaborn as sns
import numpy as np
import matplotlib.pyplot as plt
from matplotlib.ticker import MultipleLocator

def figure_formatting(): # make the plot look xmgrace-esque
    font = {'family': 'sans-serif', 'weight': 'regular', 'size': 18}
    plt.rcParams['font.sans-serif'] = ['Arial']
    plt.rc('font', **font)
    plt.rcParams['axes.linewidth'] = 2.0
    plt.rcParams['xtick.major.size'] = 10
    plt.rcParams['xtick.minor.size'] = 5
    plt.rcParams['xtick.major.width'] = 2.0
    plt.rcParams['xtick.minor.width'] = 2.0
    plt.rcParams['ytick.major.size'] = 10
    plt.rcParams['ytick.minor.size'] = 5
    plt.rcParams['ytick.major.width'] = 2.0
    plt.rcParams['ytick.minor.width'] = 2.0
    plt.rcParams['xtick.direction'] = 'in'
    plt.rcParams['ytick.direction'] = 'in'
    plt.rcParams['mathtext.default'] = 'regular'
    plt.rcParams['legend.fancybox'] = False # no rounded legend box

figure_formatting()




from matplotlib import pyplot as plt
plt.figure(figsize=(5,5))
plt.scatter(distances_1,Forces,color='#FF0000')
plt.plot(x_1,m_1*x_1+b_1,color='black',linestyle = '-')
plt.plot
plt.xlabel('Distance ($\AA$)')
plt.ylabel('External force (nN)')
plt.savefig('slopes_cis_3pt.pdf',dpi=300,bbox_inches='tight')