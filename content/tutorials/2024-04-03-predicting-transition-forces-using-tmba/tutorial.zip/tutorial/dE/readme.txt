intermediate --- all structures, input and output files needed to 
calculate energies of diradical intermediate energies. 

reagent --- all structures, input and output files needed to 
calculate energies of the reactant

*.in --- ORCA input file
*.out --- ORCA output file
*.xyz --- Geometry input file
SP/ --- Contains single point simulation input and output files and 
optimized geometry files
